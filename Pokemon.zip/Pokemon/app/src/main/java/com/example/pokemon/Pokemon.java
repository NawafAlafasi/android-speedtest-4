package com.example.pokemon;

public class Pokemon {

    String name ;
    int 
}
